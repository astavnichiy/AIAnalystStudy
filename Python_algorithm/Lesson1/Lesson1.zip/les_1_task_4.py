# -*- coding: utf-8 -*-
    
symbol1 = input("Символ 1 -")
symbol2 = input("Символ 2 -")

symbol1_num = ord(symbol1) - 96
symbol2_num = ord(symbol2) - 96

print (symbol1_num)
print (symbol2_num)


print (symbol2_num - symbol1_num)