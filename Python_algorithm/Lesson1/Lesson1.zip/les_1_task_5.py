# -*- coding: utf-8 -*-
    
symbol1_num = int(input("Номер буквы -"))

symbol1 = chr(symbol1_num + 96)

print ('Это буква -', symbol1)



